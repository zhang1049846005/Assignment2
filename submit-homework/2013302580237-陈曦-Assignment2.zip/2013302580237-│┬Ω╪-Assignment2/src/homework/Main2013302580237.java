package homework;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Main2013302580237 {

	public static void main(String[] args) {
		Connection connect = Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Ai%20Xin%20Ping");
		Document file = null;
		try {
			file = connect.timeout(100000).get();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Elements ele = file.getElementsByClass("details");
		Element result = ele.get(1);
		Element abc = ele.get(0);
		String information = abc.getElementsByTag("p").get(0).text();
		String name = abc.getElementsByTag("h3").get(0).text();		
		Pattern patt = Pattern.compile("(?<info1>.+)�о����� (?<direc>.+)��ϵ�绰�� (?<num>([0-9]+-{0,1}[0-9]+��{0,1})+) Email: (?<email>([a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+;{0,1}.)+)");
		Matcher matc = patt.matcher(information);
		Boolean boea = matc.find();
		String inf = matc.group("info1");
		String direct = matc.group("direc");
		String email = matc.group("email");	
		String phone = matc.group("num");	
		Pattern patter = Pattern.compile(">(?<content>[0-9]{4}\\.[0-9]{2}��.+)<");
		String as = result.html();
		Matcher mat2 = patter.matcher(as);
		String info2 = "";
		info2 += inf+"\r\n";
		while(!mat2.hitEnd())
		{
			if(mat2.find())
			info2 += mat2.group("content") + "\r\n";			
		}		
		info2 = info2.replaceAll("&nbsp;", " ");					
		String cout = "������" + name + "\r\n" + "��飺\r\n" + info2 + "\r\n" + "�о�����" + direct + "\r\n" + "�绰���룺"+ phone + "\r\n" + "�������䣺" + email;				
		
		BufferedWriter writer;
		try {
		writer = new BufferedWriter(new FileWriter(new File("D:\\Result.txt")));		
	    writer.write(cout);	     
	    writer.close();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}		
	}

}
