package com;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Main2014302580060 {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		Connection conn = Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Cai%20Jie");
		Document doc = null;
		try {
			doc = conn.timeout(100000).get();
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		Elements result = doc.getElementsByClass("details");
		Element result1 = result.get(0);
		Element result2 = result.get(1);
		
		String name = result1.getElementsByTag("h3").get(0).text();
		String info = result1.getElementsByTag("p").get(0).text();
		
		Pattern pat1 = Pattern.compile("(?<info1>.+)�о����� (?<direc>.+)��ϵ�绰�� (?<num>([0-9]+-{0,1}[0-9]+��{0,1})+) Email: (?<email>([a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+;{0,1}.)+)");
		Matcher mat1 = pat1.matcher(info);
		Boolean fuck = mat1.find();
		String info1 = mat1.group("info1");
		String direct = mat1.group("direc");
		String pNum = mat1.group("num");
		String email = mat1.group("email");
		
		Pattern pat2 = Pattern.compile(">(?<content>[0-9]{4}\\.[0-9]{2}��.+)<");
		String as = result2.html();
		Matcher mat2 = pat2.matcher(result2.html());
		String mInfo = "";
		mInfo += info1+"\r\n";
		while(!mat2.hitEnd())
		{
			if(mat2.find())
				mInfo += mat2.group("content") + "\r\n";
			
		}
		
		mInfo = mInfo.replaceAll("&nbsp;", " ");
		
		
		

		String fileout = "������" + name + "\r\n" + "��飺\r\n" + mInfo + "\r\n" + "�о�����" + direct + "\r\n" + "�绰���룺"
		+ pNum + "\r\n" + "�������䣺" + email + "\r\n";
		
		
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(new FileWriter(new File("Result.txt")));
		

	    writer.write(fileout);
	     
	    writer.close();
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}

		

		
		
		
		
		
		
		
		
		
		
		
		
	}

}